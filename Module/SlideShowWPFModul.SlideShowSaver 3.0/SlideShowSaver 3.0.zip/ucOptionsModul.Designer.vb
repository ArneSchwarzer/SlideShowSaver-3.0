<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ucOptionsModul
    Inherits System.Windows.Forms.UserControl

    'UserControl überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNcmbBildauswahl = New System.Windows.Forms.Label()
Me.lblNcmbBildauswahl.Tag = "langKey=lblNcmbBildauswahl"
        Me.cmbBildauswahl = New System.Windows.Forms.ComboBox()
Me.cmbBildauswahl.Tag = "langKey=cmbBildauswahl"
        Me.lblNtrbAnzeigedauer = New System.Windows.Forms.Label()
        Me.trkAnzeigedauer = New System.Windows.Forms.TrackBar()
        Me.lblAnzeigedauer = New System.Windows.Forms.Label()
Me.lblAnzeigedauer.Tag = "langKey=lblAnzeigedauer"
        Me.lblNUebergangseffekteBilder = New System.Windows.Forms.Label()
        Me.clbTransitions = New System.Windows.Forms.CheckedListBox()
Me.clbTransitions.Tag = "langKey=clbTransitions"
        Me.lblNcmbEffektauswahl = New System.Windows.Forms.Label()
Me.lblNcmbEffektauswahl.Tag = "langKey=lblNcmbEffektauswahl"
        Me.cmbEffektauswahl = New System.Windows.Forms.ComboBox()
Me.cmbEffektauswahl.Tag = "langKey=cmbEffektauswahl"
        Me.chkBildinformationen = New System.Windows.Forms.CheckBox()
Me.chkBildinformationen.Tag = "langKey=chkBildinformationen"
        Me.clbShader = New System.Windows.Forms.CheckedListBox()
Me.clbShader.Tag = "langKey=clbShader"
        Me.lblNShader = New System.Windows.Forms.Label()
        Me.cmbShaderauswahl = New System.Windows.Forms.ComboBox()
Me.cmbShaderauswahl.Tag = "langKey=cmbShaderauswahl"
        Me.lblNcmbShaderauswahl = New System.Windows.Forms.Label()
Me.lblNcmbShaderauswahl.Tag = "langKey=lblNcmbShaderauswahl"
        Me.lblModulname = New System.Windows.Forms.Label()
Me.lblModulname.Tag = "langKey=lblModulname"
        Me.lblNModulname = New System.Windows.Forms.Label()
Me.lblNModulname.Tag = "langKey=lblNModulname"
        Me.chkPräsentationsschirm = New System.Windows.Forms.CheckBox()
        Me.btnDefaults = New System.Windows.Forms.Button()
Me.btnDefaults.Tag = "langKey=btnDefaults"
        CType(Me.trkAnzeigedauer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblNcmbBildauswahl
        '
        Me.lblNcmbBildauswahl.AutoSize = True
        Me.lblNcmbBildauswahl.Location = New System.Drawing.Point(22, 123)
        Me.lblNcmbBildauswahl.Name = "lblNcmbBildauswahl"
        Me.lblNcmbBildauswahl.Size = New System.Drawing.Size(173, 41)
        Me.lblNcmbBildauswahl.TabIndex = 0
        Me.lblNcmbBildauswahl.Text = "Bildauswahl"
        '
        'cmbBildauswahl
        '
        Me.cmbBildauswahl.FormattingEnabled = True
        Me.cmbBildauswahl.Items.AddRange(New Object() {"Zufallsbild", "Zufallsverzeichnis"})
        Me.cmbBildauswahl.Location = New System.Drawing.Point(296, 115)
        Me.cmbBildauswahl.Name = "cmbBildauswahl"
        Me.cmbBildauswahl.Size = New System.Drawing.Size(565, 49)
        Me.cmbBildauswahl.TabIndex = 1
        '
        'lblNtrbAnzeigedauer
        '
        Me.lblNtrbAnzeigedauer.AutoSize = True
        Me.lblNtrbAnzeigedauer.Location = New System.Drawing.Point(19, 250)
        Me.lblNtrbAnzeigedauer.Name = "lblNtrbAnzeigedauer"
        Me.lblNtrbAnzeigedauer.Size = New System.Drawing.Size(201, 41)
        Me.lblNtrbAnzeigedauer.TabIndex = 2
        Me.lblNtrbAnzeigedauer.Tag = "langKey=lblNtrbAnzeigedauer"
        Me.lblNtrbAnzeigedauer.Text = "Anzeigedauer"
        '
        'trkAnzeigedauer
        '
        Me.trkAnzeigedauer.AutoSize = False
        Me.trkAnzeigedauer.Location = New System.Drawing.Point(296, 250)
        Me.trkAnzeigedauer.Maximum = 120
        Me.trkAnzeigedauer.Minimum = 5
        Me.trkAnzeigedauer.Name = "trkAnzeigedauer"
        Me.trkAnzeigedauer.Size = New System.Drawing.Size(427, 56)
        Me.trkAnzeigedauer.TabIndex = 3
        Me.trkAnzeigedauer.TickStyle = System.Windows.Forms.TickStyle.None
        Me.trkAnzeigedauer.Value = 15
        '
        'lblAnzeigedauer
        '
        Me.lblAnzeigedauer.AutoSize = True
        Me.lblAnzeigedauer.Location = New System.Drawing.Point(729, 250)
        Me.lblAnzeigedauer.MaximumSize = New System.Drawing.Size(129, 41)
        Me.lblAnzeigedauer.MinimumSize = New System.Drawing.Size(129, 41)
        Me.lblAnzeigedauer.Name = "lblAnzeigedauer"
        Me.lblAnzeigedauer.Size = New System.Drawing.Size(129, 41)
        Me.lblAnzeigedauer.TabIndex = 4
        Me.lblAnzeigedauer.Text = "20 s"
        Me.lblAnzeigedauer.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblNUebergangseffekteBilder
        '
        Me.lblNUebergangseffekteBilder.AutoSize = True
        Me.lblNUebergangseffekteBilder.Location = New System.Drawing.Point(19, 331)
        Me.lblNUebergangseffekteBilder.Name = "lblNUebergangseffekteBilder"
        Me.lblNUebergangseffekteBilder.Size = New System.Drawing.Size(382, 41)
        Me.lblNUebergangseffekteBilder.TabIndex = 5
        Me.lblNUebergangseffekteBilder.Tag = "langKey=lblNUebergangseffekteBilder"
        Me.lblNUebergangseffekteBilder.Text = "Übergangseffekte für Bilder"
        '
        'clbTransitions
        '
        Me.clbTransitions.FormattingEnabled = True
        Me.clbTransitions.Location = New System.Drawing.Point(26, 375)
        Me.clbTransitions.Name = "clbTransitions"
        Me.clbTransitions.Size = New System.Drawing.Size(832, 180)
        Me.clbTransitions.TabIndex = 6
        '
        'lblNcmbEffektauswahl
        '
        Me.lblNcmbEffektauswahl.AutoSize = True
        Me.lblNcmbEffektauswahl.Location = New System.Drawing.Point(26, 568)
        Me.lblNcmbEffektauswahl.Name = "lblNcmbEffektauswahl"
        Me.lblNcmbEffektauswahl.Size = New System.Drawing.Size(243, 41)
        Me.lblNcmbEffektauswahl.TabIndex = 7
        Me.lblNcmbEffektauswahl.Text = "Effektreihenfolge"
        '
        'cmbEffektauswahl
        '
        Me.cmbEffektauswahl.FormattingEnabled = True
        Me.cmbEffektauswahl.Items.AddRange(New Object() {"Zufällig bei Start", "Zufällig", "In Reihenfolge bei Start", "In Reihenfolge"})
        Me.cmbEffektauswahl.Location = New System.Drawing.Point(296, 568)
        Me.cmbEffektauswahl.Name = "cmbEffektauswahl"
        Me.cmbEffektauswahl.Size = New System.Drawing.Size(562, 49)
        Me.cmbEffektauswahl.TabIndex = 8
        '
        'chkBildinformationen
        '
        Me.chkBildinformationen.AutoSize = True
        Me.chkBildinformationen.Location = New System.Drawing.Point(26, 963)
        Me.chkBildinformationen.Name = "chkBildinformationen"
        Me.chkBildinformationen.Size = New System.Drawing.Size(414, 45)
        Me.chkBildinformationen.TabIndex = 9
        Me.chkBildinformationen.Text = "Bildinformationen anzeigen"
        Me.chkBildinformationen.UseVisualStyleBackColor = True
        '
        'clbShader
        '
        Me.clbShader.FormattingEnabled = True
        Me.clbShader.Location = New System.Drawing.Point(29, 666)
        Me.clbShader.Name = "clbShader"
        Me.clbShader.Size = New System.Drawing.Size(832, 224)
        Me.clbShader.TabIndex = 11
        '
        'lblNShader
        '
        Me.lblNShader.AutoSize = True
        Me.lblNShader.Location = New System.Drawing.Point(22, 622)
        Me.lblNShader.Name = "lblNShader"
        Me.lblNShader.Size = New System.Drawing.Size(110, 41)
        Me.lblNShader.TabIndex = 10
        Me.lblNShader.Tag = "langKey=lblNShader"
        Me.lblNShader.Text = "Shader"
        '
        'cmbShaderauswahl
        '
        Me.cmbShaderauswahl.FormattingEnabled = True
        Me.cmbShaderauswahl.Items.AddRange(New Object() {"Zufällig bei Start", "Zufällig", "In Reihenfolge bei Start", "In Reihenfolge"})
        Me.cmbShaderauswahl.Location = New System.Drawing.Point(296, 896)
        Me.cmbShaderauswahl.Name = "cmbShaderauswahl"
        Me.cmbShaderauswahl.Size = New System.Drawing.Size(565, 49)
        Me.cmbShaderauswahl.TabIndex = 13
        '
        'lblNcmbShaderauswahl
        '
        Me.lblNcmbShaderauswahl.AutoSize = True
        Me.lblNcmbShaderauswahl.Location = New System.Drawing.Point(29, 896)
        Me.lblNcmbShaderauswahl.Name = "lblNcmbShaderauswahl"
        Me.lblNcmbShaderauswahl.Size = New System.Drawing.Size(261, 41)
        Me.lblNcmbShaderauswahl.TabIndex = 12
        Me.lblNcmbShaderauswahl.Text = "Shaderreihenfolge"
        '
        'lblModulname
        '
        Me.lblModulname.AutoSize = True
        Me.lblModulname.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModulname.Location = New System.Drawing.Point(289, 29)
        Me.lblModulname.Name = "lblModulname"
        Me.lblModulname.Size = New System.Drawing.Size(292, 41)
        Me.lblModulname.TabIndex = 15
        Me.lblModulname.Text = "SlideShowSaver 3.0"
        '
        'lblNModulname
        '
        Me.lblNModulname.AutoSize = True
        Me.lblNModulname.Location = New System.Drawing.Point(22, 29)
        Me.lblNModulname.Name = "lblNModulname"
        Me.lblNModulname.Size = New System.Drawing.Size(105, 41)
        Me.lblNModulname.TabIndex = 14
        Me.lblNModulname.Tag = "lblNModulname"
        Me.lblNModulname.Text = "Modul"
        '
        'chkPräsentationsschirm
        '
        Me.chkPräsentationsschirm.AutoSize = True
        Me.chkPräsentationsschirm.Location = New System.Drawing.Point(296, 170)
        Me.chkPräsentationsschirm.Name = "chkPräsentationsschirm"
        Me.chkPräsentationsschirm.Size = New System.Drawing.Size(315, 45)
        Me.chkPräsentationsschirm.TabIndex = 16
        Me.chkPräsentationsschirm.Text = "Präsentationsschirm"
        Me.chkPräsentationsschirm.UseVisualStyleBackColor = True
        '
        'btnDefaults
        '
        Me.btnDefaults.Location = New System.Drawing.Point(673, 21)
        Me.btnDefaults.Name = "btnDefaults"
        Me.btnDefaults.Size = New System.Drawing.Size(185, 57)
        Me.btnDefaults.TabIndex = 17
        Me.btnDefaults.Text = "Standards"
        Me.btnDefaults.UseVisualStyleBackColor = True
        '
        'ucOptionsModul
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(17.0!, 41.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.btnDefaults)
        Me.Controls.Add(Me.chkPräsentationsschirm)
        Me.Controls.Add(Me.lblModulname)
        Me.Controls.Add(Me.lblNModulname)
        Me.Controls.Add(Me.cmbShaderauswahl)
        Me.Controls.Add(Me.lblNcmbShaderauswahl)
        Me.Controls.Add(Me.clbShader)
        Me.Controls.Add(Me.lblNShader)
        Me.Controls.Add(Me.chkBildinformationen)
        Me.Controls.Add(Me.cmbEffektauswahl)
        Me.Controls.Add(Me.lblNcmbEffektauswahl)
        Me.Controls.Add(Me.clbTransitions)
        Me.Controls.Add(Me.lblNUebergangseffekteBilder)
        Me.Controls.Add(Me.lblAnzeigedauer)
        Me.Controls.Add(Me.trkAnzeigedauer)
        Me.Controls.Add(Me.lblNtrbAnzeigedauer)
        Me.Controls.Add(Me.cmbBildauswahl)
        Me.Controls.Add(Me.lblNcmbBildauswahl)
        Me.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "ucOptionsModul"
        Me.Size = New System.Drawing.Size(890, 1020)
        CType(Me.trkAnzeigedauer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNcmbBildauswahl As Windows.Forms.Label
    Friend WithEvents cmbBildauswahl As Windows.Forms.ComboBox
    Friend WithEvents lblNtrbAnzeigedauer As Windows.Forms.Label
    Friend WithEvents trkAnzeigedauer As Windows.Forms.TrackBar
    Friend WithEvents lblAnzeigedauer As Windows.Forms.Label
    Friend WithEvents lblNUebergangseffekteBilder As Windows.Forms.Label
    Friend WithEvents clbTransitions As Windows.Forms.CheckedListBox
    Friend WithEvents lblNcmbEffektauswahl As Windows.Forms.Label
    Friend WithEvents cmbEffektauswahl As Windows.Forms.ComboBox
    Friend WithEvents chkBildinformationen As Windows.Forms.CheckBox
    Friend WithEvents clbShader As Windows.Forms.CheckedListBox
    Friend WithEvents lblNShader As Windows.Forms.Label
    Friend WithEvents cmbShaderauswahl As Windows.Forms.ComboBox
    Friend WithEvents lblNcmbShaderauswahl As Windows.Forms.Label
    Friend WithEvents lblModulname As Windows.Forms.Label
    Friend WithEvents lblNModulname As Windows.Forms.Label
    Friend WithEvents chkPräsentationsschirm As Forms.CheckBox
    Friend WithEvents btnDefaults As Forms.Button
End Class