﻿Imports System.Collections.Generic
Imports System.Windows.Media
Imports System.Windows.Media.Imaging

''' <summary>
''' Repräsentiert eine komplexe Zahl mit Double-Genauigkeit.
''' </summary>
Public Structure MandelbrotComplex

    Public Property Real As Double
    Public Property Imaginary As Double

    Public Sub New(real As Double, imaginary As Double)

        Me.Real = real
        Me.Imaginary = imaginary

    End Sub

End Structure


''' <summary>
''' Berechnet und verwaltet den Referenzorbit eines Punktes
''' innerhalb der komplexen Mandelbrot-Ebene.
''' </summary>
Public Class MandelbrotReferenzOrbit

#Region "Variablendeklaration"

    Private ReadOnly orbitIntern As List(Of MandelbrotComplex)
    Public ReadOnly Property TexturBreite As Integer
        Get
            Return BerechneNaechsteZweierpotenz(orbitIntern.Count)
        End Get
    End Property

#End Region

#Region "Eigenschaften"

    ''' <summary>
    ''' Realteil des Referenzpunktes.
    ''' </summary>
    Public ReadOnly Property CenterX As Double

    ''' <summary>
    ''' Imaginärteil des Referenzpunktes.
    ''' </summary>
    Public ReadOnly Property CenterY As Double

    ''' <summary>
    ''' Maximale Anzahl der zu berechnenden Iterationen.
    ''' </summary>
    Public ReadOnly Property MaxIterationen As Integer

    ''' <summary>
    ''' Nur lesbarer Zugriff auf die berechneten Orbitwerte.
    ''' </summary>
    Public ReadOnly Property Orbit As IReadOnlyList(Of MandelbrotComplex)
        Get
            Return orbitIntern
        End Get
    End Property

    ''' <summary>
    ''' Anzahl der tatsächlich berechneten Orbitwerte.
    ''' </summary>
    Public ReadOnly Property Count As Integer
        Get
            Return orbitIntern.Count
        End Get
    End Property

#End Region

#Region "Konstruktor"

    Public Sub New(centerX As Double,
                   centerY As Double,
                   maxIterationen As Integer)

        If maxIterationen <= 0 Then
            Throw New ArgumentOutOfRangeException(
                NameOf(maxIterationen),
                "Die maximale Iterationszahl muss größer als 0 sein.")
        End If

        Me.CenterX = centerX
        Me.CenterY = centerY
        Me.MaxIterationen = maxIterationen

        orbitIntern = BerechneOrbit()

    End Sub

#End Region

#Region "Öffentliche Funktionen"

    ''' <summary>
    ''' Liefert den Orbitwert an der angegebenen Position.
    ''' </summary>
    Public Function Item(index As Integer) As MandelbrotComplex

        If index < 0 OrElse index >= orbitIntern.Count Then
            Throw New ArgumentOutOfRangeException(
                NameOf(index),
                "Der angegebene Orbitindex liegt außerhalb des gültigen Bereichs.")
        End If

        Return orbitIntern(index)

    End Function

    Public Function ErzeugeRealOrbitBrush() As ImageBrush

        Return ErzeugeOrbitBrush(True)

    End Function

    Public Function ErzeugeImaginaryOrbitBrush() As ImageBrush

        Return ErzeugeOrbitBrush(False)

    End Function

#End Region

#Region "Orbit-Berechnung"

    ''' <summary>
    ''' Berechnet die Referenzbahn Z(n+1) = Z(n)^2 + C.
    ''' Z0 wird als erster Eintrag gespeichert.
    ''' </summary>
    Private Function BerechneOrbit() As List(Of MandelbrotComplex)

        Dim ergebnis As List(Of MandelbrotComplex)
        Dim zReal As Double
        Dim zImaginary As Double
        Dim zRealQuadrat As Double
        Dim zImaginaryQuadrat As Double
        Dim neuerRealteil As Double
        Dim neuerImaginaerteil As Double
        Dim betragQuadrat As Double
        Dim i As Integer

        ergebnis = New List(Of MandelbrotComplex)(MaxIterationen)

        zReal = 0.0
        zImaginary = 0.0

        For i = 0 To MaxIterationen - 1

            ' Z(n) speichern, bevor Z(n+1) berechnet wird.
            ergebnis.Add(
                New MandelbrotComplex(
                    zReal,
                    zImaginary))

            zRealQuadrat = zReal * zReal
            zImaginaryQuadrat = zImaginary * zImaginary

            neuerRealteil =
                zRealQuadrat -
                zImaginaryQuadrat +
                CenterX

            neuerImaginaerteil =
                2.0 *
                zReal *
                zImaginary +
                CenterY

            zReal = neuerRealteil
            zImaginary = neuerImaginaerteil

            betragQuadrat =
                zReal * zReal +
                zImaginary * zImaginary

            If betragQuadrat > 4.0 Then
                Exit For
            End If

        Next

        Return ergebnis

    End Function

#End Region

    Private Function ErzeugeOrbitBrush(realteil As Boolean) As ImageBrush

        Dim texturBreite As Integer
        Dim pixelDaten() As Single
        Dim orbitWert As MandelbrotComplex
        Dim wert As Double
        Dim high As Single
        Dim low As Single
        Dim pixelOffset As Integer
        Dim letzterIndex As Integer
        Dim bitmap As BitmapSource
        Dim brush As ImageBrush
        Dim i As Integer

        If orbitIntern Is Nothing OrElse orbitIntern.Count = 0 Then
            Throw New InvalidOperationException(
                "Der Referenzorbit enthält keine Werte.")
        End If

        'Zweierpotenz ist für ältere D3D9-Hardware die
        'kompatibelste Texturgröße.
        texturBreite = BerechneNaechsteZweierpotenz(
            orbitIntern.Count)

        ReDim pixelDaten(texturBreite * 4 - 1)

        letzterIndex = orbitIntern.Count - 1

        For i = 0 To texturBreite - 1

            'Nicht benötigte Texel werden mit dem letzten
            'gültigen Orbitwert aufgefüllt.
            orbitWert = orbitIntern(Math.Min(i, letzterIndex))

            If realteil Then
                wert = orbitWert.Real
            Else
                wert = orbitWert.Imaginary
            End If

            SplitDouble(wert, high, low)

            pixelOffset = i * 4

            'Rgba128Float:
            'R = High, G = Low, B = 0, A = 1
            pixelDaten(pixelOffset + 0) = high
            pixelDaten(pixelOffset + 1) = low
            pixelDaten(pixelOffset + 2) = 0.0F
            pixelDaten(pixelOffset + 3) = 1.0F

        Next

        bitmap = BitmapSource.Create(
            texturBreite,
            1,
            96.0,
            96.0,
            PixelFormats.Rgba128Float,
            Nothing,
            pixelDaten,
            texturBreite * 16)

        bitmap.Freeze()

        brush = New ImageBrush(bitmap)

        With brush
            .Stretch = Stretch.Fill
            .TileMode = TileMode.None
            .AlignmentX = AlignmentX.Left
            .AlignmentY = AlignmentY.Top
        End With

        brush.Freeze()

        Return brush

    End Function

    Private Function BerechneNaechsteZweierpotenz(value As Integer) As Integer

        Dim result As Integer

        result = 1

        While result < value
            result *= 2
        End While

        Return Math.Max(2, result)

    End Function

    Private Sub SplitDouble(value As Double,
                            ByRef high As Single,
                            ByRef low As Single)

        high = CSng(value)
        low = CSng(value - CDbl(high))

    End Sub
End Class