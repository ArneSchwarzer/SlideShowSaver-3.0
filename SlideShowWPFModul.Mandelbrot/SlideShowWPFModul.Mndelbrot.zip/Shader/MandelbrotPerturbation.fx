// ============================================================
// MandelbrotPerturbation.fx
//
// Perturbation Rendering:
//     Z(n+1) = Z(n)^2 + C
//
// Pixelbahn:
//     Z(n) + dZ(n)
//
// Perturbationsgleichung:
//     dZ(n+1) = 2 * Z(n) * dZ(n)
//               + dZ(n)^2
//               + dC
//
// Referenzorbit:
//     s1 = Realteil, jeweils High/Low in R/G
//     s2 = ImaginÃ¤rteil, jeweils High/Low in R/G
// ============================================================


// ------------------------------------------------------------
// Texturen
// ------------------------------------------------------------

sampler2D GradientSampler : register(s0);

sampler2D ReferenceOrbitRealSampler : register(s1);
sampler2D ReferenceOrbitImagSampler : register(s2);


// ------------------------------------------------------------
// Shaderkonstanten
// ------------------------------------------------------------

float ScaleHigh : register(c0);
float ScaleLow : register(c1);

float MaxIterations : register(c2);
float OrbitLength : register(c3);
float OrbitTextureWidth : register(c4);

float ViewportWidth : register(c5);
float ViewportHeight : register(c6);

float GradientOffset : register(c7);
float Rotation : register(c8);


// ============================================================
// Double-Single-Arithmetik
//
// float2:
//     x = High-Anteil
//     y = Low-Anteil
// ============================================================

float2 ds_set(float value)
{
    return float2(value, 0.0);
}


float2 ds_normalize(float2 value)
{
    float high;
    float low;

    high = value.x + value.y;
    low = value.y - (high - value.x);

    return float2(high, low);
}


float2 ds_add(float2 a, float2 b)
{
    float sum;
    float virtualB;
    float error;
    float resultHigh;
    float resultLow;

    sum = a.x + b.x;
    virtualB = sum - a.x;

    error =
        (a.x - (sum - virtualB)) +
        (b.x - virtualB) +
        a.y +
        b.y;

    resultHigh = sum + error;
    resultLow = error - (resultHigh - sum);

    return float2(resultHigh, resultLow);
}


float2 ds_sub(float2 a, float2 b)
{
    return ds_add(
        a,
        float2(-b.x, -b.y));
}


float2 ds_mul(float2 a, float2 b)
{
    const float split = 4097.0;

    float conA;
    float conB;

    float aHigh;
    float aLow;
    float bHigh;
    float bLow;

    float productHigh;
    float productError;

    conA = a.x * split;
    conB = b.x * split;

    aHigh = conA - (conA - a.x);
    bHigh = conB - (conB - b.x);

    aLow = a.x - aHigh;
    bLow = b.x - bHigh;

    productHigh = a.x * b.x;

    productError =
        (((aHigh * bHigh - productHigh) +
          aHigh * bLow) +
          aLow * bHigh) +
          aLow * bLow;

    productError +=
        a.x * b.y +
        a.y * b.x;

    return ds_normalize(
        float2(productHigh, productError));
}


float2 ds_mul_float(float2 a, float b)
{
    return ds_mul(
        a,
        ds_set(b));
}


float ds_to_float(float2 value)
{
    return value.x + value.y;
}


// ============================================================
// Komplexe Double-Single-Zahl
//
// Realteil und ImaginÃ¤rteil werden getrennt als float2 gefÃ¼hrt.
// ============================================================

struct ComplexDS
{
    float2 Real;
    float2 Imaginary;
};


ComplexDS complex_zero()
{
    ComplexDS result;

    result.Real = ds_set(0.0);
    result.Imaginary = ds_set(0.0);

    return result;
}


ComplexDS complex_add(ComplexDS a, ComplexDS b)
{
    ComplexDS result;

    result.Real =
        ds_add(a.Real, b.Real);

    result.Imaginary =
        ds_add(a.Imaginary, b.Imaginary);

    return result;
}


ComplexDS complex_square(ComplexDS value)
{
    ComplexDS result;

    float2 realSquared;
    float2 imaginarySquared;
    float2 realImaginary;

    realSquared =
        ds_mul(value.Real, value.Real);

    imaginarySquared =
        ds_mul(value.Imaginary, value.Imaginary);

    realImaginary =
        ds_mul(value.Real, value.Imaginary);

    result.Real =
        ds_sub(
            realSquared,
            imaginarySquared);

    result.Imaginary =
        ds_mul_float(
            realImaginary,
            2.0);

    return result;
}


ComplexDS complex_multiply(ComplexDS a, ComplexDS b)
{
    ComplexDS result;

    float2 realReal;
    float2 imagImag;
    float2 realImag;
    float2 imagReal;

    realReal =
        ds_mul(a.Real, b.Real);

    imagImag =
        ds_mul(a.Imaginary, b.Imaginary);

    realImag =
        ds_mul(a.Real, b.Imaginary);

    imagReal =
        ds_mul(a.Imaginary, b.Real);

    result.Real =
        ds_sub(
            realReal,
            imagImag);

    result.Imaginary =
        ds_add(
            realImag,
            imagReal);

    return result;
}


ComplexDS complex_multiply_float(ComplexDS value, float factor)
{
    ComplexDS result;

    result.Real =
        ds_mul_float(value.Real, factor);

    result.Imaginary =
        ds_mul_float(value.Imaginary, factor);

    return result;
}


// ============================================================
// Referenzorbit aus den Texturen lesen
// ============================================================

ComplexDS ReadReferenceOrbit(int index)
{
    ComplexDS result;

    float textureU;
    float4 textureCoordinate;
    float4 realSample;
    float4 imaginarySample;

    // Mitte des gew�nschten Texels.
    textureU =
        ((float)index + 0.5) /
        max(OrbitTextureWidth, 1.0);

    // tex2Dlod erwartet:
    // x = U
    // y = V
    // z = unbenutzt
    // w = expliziter Mipmap-Level
    textureCoordinate =
        float4(
            textureU,
            0.5,
            0.0,
            0.0);

    realSample =
        tex2Dlod(
            ReferenceOrbitRealSampler,
            textureCoordinate);

    imaginarySample =
        tex2Dlod(
            ReferenceOrbitImagSampler,
            textureCoordinate);

    // R = High, G = Low
    result.Real =
        float2(
            realSample.r,
            realSample.g);

    result.Imaginary =
        float2(
            imaginarySample.r,
            imaginarySample.g);

    return result;
}


// ============================================================
// Gradient
// ============================================================

float3 GetPaletteColor(float t)
{
    t = frac(t + GradientOffset);

    return tex2D(
        GradientSampler,
        float2(t, 0.5)).rgb;
}


// ============================================================
// Pixel Shader
// ============================================================

float4 main(float2 uv : TEXCOORD) : COLOR
{
    float aspect;

    float pixelX;
    float pixelY;

    float cosRotation;
    float sinRotation;

    float rotatedX;
    float rotatedY;

    float2 scale;

    ComplexDS deltaC;
    ComplexDS deltaZ;

    ComplexDS referenceZ;
    ComplexDS actualZ;

    ComplexDS termReference;
    ComplexDS termDeltaSquared;

    float actualReal;
    float actualImaginary;
    float magnitudeSquared;

    float iteration;
    float colorPosition;

    int iterationLimit;
    int i;


    // --------------------------------------------------------
    // Pixelposition relativ zum Referenzzentrum
    // --------------------------------------------------------

    aspect =
        ViewportWidth /
        max(ViewportHeight, 1.0);

    pixelX =
        (uv.x - 0.5) *
        aspect;

    pixelY =
        uv.y - 0.5;


    // --------------------------------------------------------
    // Rotation vorbereiten
    //
    // Rotation wird von VB derzeit noch mit 0 Ã¼bergeben.
    // Die Logik ist aber bereits vollstÃ¤ndig vorbereitet.
    // --------------------------------------------------------

    cosRotation = cos(Rotation);
    sinRotation = sin(Rotation);

    rotatedX =
        pixelX * cosRotation -
        pixelY * sinRotation;

    rotatedY =
        pixelX * sinRotation +
        pixelY * cosRotation;


    // --------------------------------------------------------
    // dC = rotierter Pixeloffset * Scale
    // --------------------------------------------------------

    scale =
        float2(
            ScaleHigh,
            ScaleLow);

    deltaC.Real =
        ds_mul_float(
            scale,
            rotatedX);

    deltaC.Imaginary =
        ds_mul_float(
            scale,
            rotatedY);


    // --------------------------------------------------------
    // Startwert dZ0 = 0
    // --------------------------------------------------------

    deltaZ = complex_zero();

    iteration = MaxIterations;

    iterationLimit =
        (int) min(
            MaxIterations,
            OrbitLength);


    // --------------------------------------------------------
    // Perturbationsiteration
    // --------------------------------------------------------

    [loop]
    for (i = 0; i < 2000; i++)
    {
        if (i >= iterationLimit)
        {
            break;
        }


        // Referenzwert Z(i)
        referenceZ =
            ReadReferenceOrbit(i);


        // TatsÃ¤chlicher Pixelwert:
        //
        // z(i) = Z(i) + dZ(i)
        actualZ =
            complex_add(
                referenceZ,
                deltaZ);


        // Escape-Test
        actualReal =
            ds_to_float(actualZ.Real);

        actualImaginary =
            ds_to_float(actualZ.Imaginary);

        magnitudeSquared =
            actualReal * actualReal +
            actualImaginary * actualImaginary;

        if (magnitudeSquared > 4.0)
        {
            iteration = (float) i;
            break;
        }


        // ----------------------------------------------------
        // dZ(n+1) =
        //     2 * Z(n) * dZ(n)
        //     + dZ(n)^2
        //     + dC
        // ----------------------------------------------------

        termReference =
            complex_multiply(
                referenceZ,
                deltaZ);

        termReference =
            complex_multiply_float(
                termReference,
                2.0);

        termDeltaSquared =
            complex_square(deltaZ);

        deltaZ =
            complex_add(
                termReference,
                termDeltaSquared);

        deltaZ =
            complex_add(
                deltaZ,
                deltaC);
    }


    // --------------------------------------------------------
    // Punkt innerhalb der betrachteten Iterationszahl
    // --------------------------------------------------------

    if (iteration >= MaxIterations)
    {
        return float4(
            0.0,
            0.0,
            0.0,
            1.0);
    }


    // --------------------------------------------------------
    // Farbzuweisung
    // --------------------------------------------------------

    colorPosition =
        iteration /
        max(MaxIterations, 1.0);

    return float4(
        GetPaletteColor(colorPosition),
        1.0);
}