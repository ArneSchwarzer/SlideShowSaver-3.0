﻿Imports System.Windows
Imports System.Windows.Media
Imports System.Windows.Media.Effects

Public Class MandelbrotEffect
    Inherits ShaderEffect

    Private Shared ReadOnly _pixelShader As New PixelShader()

    Shared Sub New()
        _pixelShader.UriSource = New Uri(
            "pack://application:,,,/SlideShowWPFModul.Mandelbrot;component/Shader/Mandelbrot.ps",
            UriKind.Absolute)
    End Sub

    Public Sub New()
        PixelShader = _pixelShader

        UpdateShaderValue(CenterXProperty)
        UpdateShaderValue(CenterYProperty)
        UpdateShaderValue(ScaleProperty)
        UpdateShaderValue(MaxIterationsProperty)
        UpdateShaderValue(ViewportWidthProperty)
        UpdateShaderValue(ViewportHeightProperty)
        UpdateShaderValue(GradientOffsetProperty)
        UpdateShaderValue(GradientIndexProperty)
    End Sub

    Public Shared ReadOnly CenterXProperty As DependencyProperty =
        DependencyProperty.Register(
            "CenterX",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(-0.5R, PixelShaderConstantCallback(0)))

    Public Property CenterX As Double
        Get
            Return CDbl(GetValue(CenterXProperty))
        End Get
        Set(value As Double)
            SetValue(CenterXProperty, value)
        End Set
    End Property

    Public Shared ReadOnly CenterYProperty As DependencyProperty =
        DependencyProperty.Register(
            "CenterY",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(0.0R, PixelShaderConstantCallback(1)))

    Public Property CenterY As Double
        Get
            Return CDbl(GetValue(CenterYProperty))
        End Get
        Set(value As Double)
            SetValue(CenterYProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ScaleProperty As DependencyProperty =
        DependencyProperty.Register(
            "Scale",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(3.0R, PixelShaderConstantCallback(2)))

    Public Property Scale As Double
        Get
            Return CDbl(GetValue(ScaleProperty))
        End Get
        Set(value As Double)
            SetValue(ScaleProperty, value)
        End Set
    End Property

    Public Shared ReadOnly MaxIterationsProperty As DependencyProperty =
        DependencyProperty.Register(
            "MaxIterations",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(200.0R, PixelShaderConstantCallback(3)))

    Public Property MaxIterations As Double
        Get
            Return CDbl(GetValue(MaxIterationsProperty))
        End Get
        Set(value As Double)
            SetValue(MaxIterationsProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ViewportWidthProperty As DependencyProperty =
        DependencyProperty.Register(
            "ViewportWidth",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(1920.0R, PixelShaderConstantCallback(4)))

    Public Property ViewportWidth As Double
        Get
            Return CDbl(GetValue(ViewportWidthProperty))
        End Get
        Set(value As Double)
            SetValue(ViewportWidthProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ViewportHeightProperty As DependencyProperty =
        DependencyProperty.Register(
            "ViewportHeight",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(1080.0R, PixelShaderConstantCallback(5)))

    Public Property ViewportHeight As Double
        Get
            Return CDbl(GetValue(ViewportHeightProperty))
        End Get
        Set(value As Double)
            SetValue(ViewportHeightProperty, value)
        End Set
    End Property

    Public Shared ReadOnly GradientOffsetProperty As DependencyProperty =
        DependencyProperty.Register(
            "GradientOffset",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(0.0R, PixelShaderConstantCallback(6)))

    Public Property GradientOffset As Double
        Get
            Return CDbl(GetValue(GradientOffsetProperty))
        End Get
        Set(value As Double)
            SetValue(GradientOffsetProperty, value)
        End Set
    End Property

    Public Shared ReadOnly GradientIndexProperty As DependencyProperty =
        DependencyProperty.Register(
            "GradientIndex",
            GetType(Double),
            GetType(MandelbrotEffect),
            New UIPropertyMetadata(0.0R, PixelShaderConstantCallback(7)))

    Public Property GradientIndex As Double
        Get
            Return CDbl(GetValue(GradientIndexProperty))
        End Get
        Set(value As Double)
            SetValue(GradientIndexProperty, value)
        End Set
    End Property

End Class