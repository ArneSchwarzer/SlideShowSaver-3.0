// ============================================================
// MandelbrotPerturbation.fx
//
// Tempor�rer Platzhalter w�hrend der Entwicklung des
// Multipass-Proof-of-Concepts.
//
// Der produktive Perturbationsshader wird sp�ter auf Basis
// der funktionierenden Multipass-Architektur neu aufgebaut.
//
// Dieser Shader enth�lt bewusst:
// - keine Iterationsschleife
// - keine Orbitberechnung
// - keine Perturbationsmathematik
//
// Er reicht lediglich die Gradiententextur unver�ndert durch.
// ============================================================


// ------------------------------------------------------------
// Sampler
// ------------------------------------------------------------

sampler2D GradientSampler
    : register(s0);


// ------------------------------------------------------------
// Hauptshader
// ------------------------------------------------------------

float4 main(
    float2 uv : TEXCOORD) : COLOR
{
    return
        tex2D(
            GradientSampler,
            uv);
}