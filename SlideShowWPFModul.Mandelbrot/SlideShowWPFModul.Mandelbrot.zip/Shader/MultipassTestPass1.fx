// ============================================================
// MultipassTestPass1.fx
//
// Erster Pass des Multipass-Proof-of-Concepts.
//
// Vier bekannte Werte werden als 24-Bit-Zahlen in RGB codiert:
//
// oben links:    0,10
// oben rechts:   0,30
// unten links:   0,55
// unten rechts:  0,75
//
// Alpha bleibt immer 1,0.
// ============================================================


// ============================================================
// 24-Bit-Codierung
// ============================================================

float4 Encode24BitNormalized(
    float value)
{
    float encodedValue;

    float redByte;
    float greenByte;
    float blueByte;

    value =
        saturate(
            value);

    encodedValue =
        floor(
            value *
            16777215.0 +
            0.5);

    redByte =
        floor(
            encodedValue /
            65536.0);

    encodedValue -=
        redByte *
        65536.0;

    greenByte =
        floor(
            encodedValue /
            256.0);

    blueByte =
        encodedValue -
        greenByte *
        256.0;

    return float4(
        redByte / 255.0,
        greenByte / 255.0,
        blueByte / 255.0,
        1.0);
}


// ============================================================
// Hauptshader
// ============================================================

float4 main(
    float2 uv : TEXCOORD) : COLOR
{
    float testValue;

    if (uv.x < 0.5)
    {
        if (uv.y < 0.5)
        {
            testValue =
                0.10;
        }
        else
        {
            testValue =
                0.55;
        }
    }
    else
    {
        if (uv.y < 0.5)
        {
            testValue =
                0.30;
        }
        else
        {
            testValue =
                0.75;
        }
    }

    return
        Encode24BitNormalized(
            testValue);
}