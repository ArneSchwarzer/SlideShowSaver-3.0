﻿Imports System
Imports System.Windows.Media.Effects

Public Class MultipassTestPass1Effect
    Inherits ShaderEffect

#Region "Shader"

    Private Shared ReadOnly pixelShaderIntern As PixelShader

    Shared Sub New()

        pixelShaderIntern =
            New PixelShader With {
                .UriSource =
                    New Uri(
                        "pack://application:,,,/" &
                        "SlideShowWPFModul.Mandelbrot;" &
                        "component/Shader/" &
                        "MultipassTestPass1.ps",
                        UriKind.Absolute)
            }

    End Sub

#End Region

    Public Sub New()

        PixelShader =
            pixelShaderIntern

    End Sub

End Class