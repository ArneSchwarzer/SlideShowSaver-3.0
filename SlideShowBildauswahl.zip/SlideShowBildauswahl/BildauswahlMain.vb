﻿Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Imports System.IO

Public Class BildauswahlMain

    'Variablen, Konstanten und Enums

    Public Enum Ausrichtung
        Normal = 1                 ' Keine Drehung
        SpiegelHorizontal = 2
        Drehung180 = 3
        SpiegelVertikal = 4
        Drehung90SpiegelVertikal = 5
        Drehung90 = 6
        Drehung90SpiegelHorizontal = 7
        Drehung270 = 8
    End Enum

    Public Shared Function GetBildauswahlDefaultSettings() As Dictionary(Of String, String)
        Dim defaults As New Dictionary(Of String, String)

        defaults("Verzeichnisse") = "D:\Arbeitsverzeichnis;D:\Eigene Bilder" 'Liste der Verzeichnisse (durch Semikola getrennt) 
        defaults("WhiteListTags") = "" 'Liste der Tags in der White-List (durch Semikola getrennt)
        defaults("BlackListTags") = "Extern; 18+; Akt; Anna_Akt; Kiki_Akt; Daphne_Akt; Sirenen_Akt" 'Liste der Tags in der Black-List (durch Semikola getrennt)
        defaults("Altersfreigabe") = "Lingerie" 'Stufe der Altersfreigabe
        defaults("Bewertung") = "4 Sterne" 'Minimale Bewertung

        Return defaults
    End Function

    Public Shared Sub WriteBildauswahlSettingsToRegistry(settings As Dictionary(Of String, String))
        'Registry-Werte Schreiben
    End Sub

    Public Shared Function GetCurrentScreen() As Image
        'Screenshot erstellen
    End Function

    Public Shared Function GetPictures(n As Integer, Optional correctOrientation As Boolean = True, Optional targetDir As String = "") As List(Of Image)
        ' n Bilder werden gemäß den Einstellungen zufällig geladen. Die Liste der Bilder ist unsortiert.
        ' Die Bilder werden gemäß MetaDaten korrekt ausgerichtet, solange der optionale Parameter correctOrientation nicht FALSE ist.
        ' Ein optionales targetDir beschränkt die Suche auf ebendieses.
    End Function

    Public Shared Function GetPicturesByDirectory(Optional correctOrientation As Boolean = True, Optional targetDir As String = "") As List(Of Image)
        ' Alle Bilder eines zufällig bestimmten Verzeichnisses werden gemäß den Einstellungen geladen
        ' Die Liste der Bilder ist alphabetisch sortiert.
        ' Die Bilder werden korrekt gemäß MetaDaten ausgerichtet, solange der optionale Parameter correctOrientation nicht False ist.
        ' Ein optionales targetDir gibt alle gemäß Einstellungen legitimen Bilder ebendieses Verzeichnisses aus
    End Function

    Public Shared Function CorrectPictureOrientation(img As Image, orientation As Ausrichtung, Optional horizontalFlip As Boolean = False, Optional verticalFlip As Boolean = False) As Image
        ' Korrigiert die Orientierung eines Bildes gemäß dem Parameter orientation.
        ' Optional kann das Bild horizontal oder vertikal gespiegelt werden
        Dim rotateFlipType As RotateFlipType = RotateFlipType.RotateNoneFlipNone

        ' Zuerst die Rotation
        Select Case orientation
            Case Ausrichtung.Drehung90
                rotateFlipType = RotateFlipType.Rotate90FlipNone
            Case Ausrichtung.Drehung180
                rotateFlipType = RotateFlipType.Rotate180FlipNone
            Case Ausrichtung.Drehung270
                rotateFlipType = RotateFlipType.Rotate270FlipNone
            Case Else
                rotateFlipType = RotateFlipType.RotateNoneFlipNone
        End Select

        ' Danach die Spiegelung
        If horizontalFlip AndAlso verticalFlip Then
            rotateFlipType = CombineFlip(rotateFlipType, RotateFlipType.RotateNoneFlipXY)
        ElseIf horizontalFlip Then
            rotateFlipType = CombineFlip(rotateFlipType, RotateFlipType.RotateNoneFlipX)
        ElseIf verticalFlip Then
            rotateFlipType = CombineFlip(rotateFlipType, RotateFlipType.RotateNoneFlipY)
        End If

        ' Neues Bild erstellen und transformieren
        Dim newImg As Image = CType(img.Clone(), Image)
        newImg.RotateFlip(rotateFlipType)
        Return newImg

    End Function

    ''' <summary>
    ''' Dreht ein Bild um den angegebenen Winkel angle.
    ''' </summary>
    ''' <param name="img">Das zu drehende Originalbild.</param>
    ''' <param name="angle">Der Rotationswinkel in Grad (im Uhrzeigersinn, negative Werte gegen den Uhrzeigersinn).</param>
    ''' <returns>Ein neues Image-Objekt, das um angle Grad rotiert wurde. Transparente Ränder werden gesetzt.</returns>
    Public Shared Function RotateImage(img As Image, angle As Single) As Image
        ' Normalisiere Winkel auf [0, 360)
        angle = angle Mod 360
        If angle < 0 Then angle += 360

        ' Umwandlung in Radiant
        Dim angleRad As Double = angle * Math.PI / 180.0

        ' Ursprüngliche Maße
        Dim originalWidth As Integer = img.Width
        Dim originalHeight As Integer = img.Height

        ' Berechne die Größe des neuen Bildes nach Rotation
        Dim cos As Double = Math.Abs(Math.Cos(angleRad))
        Dim sin As Double = Math.Abs(Math.Sin(angleRad))

        Dim newWidth As Integer = CInt(Math.Round(originalWidth * cos + originalHeight * sin))
        Dim newHeight As Integer = CInt(Math.Round(originalWidth * sin + originalHeight * cos))

        ' Neues Bitmap mit transparentem Hintergrund
        Dim rotatedBmp As New Bitmap(newWidth, newHeight, PixelFormat.Format32bppArgb)
        rotatedBmp.SetResolution(img.HorizontalResolution, img.VerticalResolution)

        ' Rotationszentrum berechnen
        Dim cx As Single = newWidth / 2
        Dim cy As Single = newHeight / 2

        Using g As Graphics = Graphics.FromImage(rotatedBmp)
            g.SmoothingMode = SmoothingMode.AntiAlias
            g.InterpolationMode = InterpolationMode.HighQualityBicubic
            g.PixelOffsetMode = PixelOffsetMode.HighQuality
            g.Clear(Color.Transparent)

            ' Transformation durchführen
            g.TranslateTransform(cx, cy)
            g.RotateTransform(angle)
            g.TranslateTransform(-originalWidth / 2.0F, -originalHeight / 2.0F)

            ' Originalbild zeichnen
            g.DrawImage(img, New PointF(0, 0))
        End Using

        Return rotatedBmp
    End Function

    ''' <summary>
    ''' Liest das EXIF-Orientierungsfeld (falls vorhanden) aus einer Bilddatei
    ''' und gibt es als Ausrichtung-Enum zurück.
    ''' </summary>
    ''' <param name="img">Das geladene Image-Objekt (z. B. via Image.FromFile).</param>
    ''' <returns>Wert aus dem Enum Ausrichtung. Fällt auf Normal zurück, wenn keine EXIF-Info vorhanden.</returns>
    Public Shared Function GetExifOrientation(img As Image) As Ausrichtung
        Const orientationPropertyId As Integer = 274 ' Standard-EXIF-ID für Orientation

        Try
            If img.PropertyIdList.Contains(orientationPropertyId) Then
                Dim prop As PropertyItem = img.GetPropertyItem(orientationPropertyId)
                Dim orientationValue As Integer = BitConverter.ToUInt16(prop.Value, 0)

                If [Enum].IsDefined(GetType(Ausrichtung), orientationValue) Then
                    Return CType(orientationValue, Ausrichtung)
                End If
            End If
        Catch ex As Exception
            ' Logge optional Fehler oder ignoriere
        End Try

        Return Ausrichtung.Normal
    End Function

    Private Shared Function CombineFlip(baseRotation As RotateFlipType, flip As RotateFlipType) As RotateFlipType
        ' Nur Flip-Kombinationen modifizieren – Rotation bleibt wie sie ist
        Dim rotationPart = baseRotation And RotateFlipType.Rotate180FlipNone
        Dim flipPart = baseRotation And Not RotateFlipType.Rotate180FlipNone

        ' Flip-Part austauschen
        Return rotationPart Or flip
    End Function

End Class
